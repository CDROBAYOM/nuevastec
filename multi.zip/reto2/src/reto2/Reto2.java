/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reto2;

import java.util.Arrays;

/**
 *
 * @author ASUS-PC
 */
public class Reto2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] a = {{1, 2, -3}, {4, 0, -2},{4, 0, -2}};
        int[][] b = {{3, 1, 3}, {2, 4, 3}, {-1, 5, 3}};
        int[][] c = multiply(a, b);
        System.out.println(Arrays.deepToString(c));
    }

    private static int[][] multiply(int[][] a, int[][] b) {
        int[][] c = new int[a.length][b[0].length];
        // se comprueba si las matrices se pueden multiplicar
        if (a[0].length == b.length) {
            for (int i = 0; i < a.length; i++) {
                for (int j = 0; j < b[0].length; j++) {
                    for (int k = 0; k < a[0].length; k++) {
                        // aquí se multiplica la matriz
                        c[i][j] += a[i][k] * b[k][j];
                    }
                }
            }
        }
        return c;
    }
}
